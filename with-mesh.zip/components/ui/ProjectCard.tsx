import Image from "next/image";
import Link from "next/link";
import { Card } from "./Card";

export interface Project {
  title: string;
  description: string;
  link?: string;
  image?: string;
  tags?: string[];
}

interface ProjectCardProps {
  project: Project;
}

export function ProjectCard({ project }: ProjectCardProps) {
  return (
    <Card className="snap-start shrink-0 w-[85vw] md:w-[45vw] lg:w-[calc(33.333%-1rem)] p-5 flex flex-col justify-between bg-[#0A0D18]/50 backdrop-blur-md border-white/5 hover:border-white/10 transition-colors rounded-[24px] group overflow-hidden">
      <div className="flex flex-col h-full">
        {/* Site Preview / Image */}
        <div className="w-full aspect-[16/10] bg-[#060913] rounded-xl mb-6 overflow-hidden relative flex items-center justify-center group/preview border border-white/5">
          {project.image ? (
            <Image 
              src={project.image} 
              alt={project.title} 
              fill 
              className="object-cover object-top opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-700" 
              sizes="(max-width: 768px) 85vw, (max-width: 1200px) 45vw, 33vw" 
            />
          ) : (
            <div className="text-muted-foreground/30 font-medium text-sm">No Preview</div>
          )}

          {/* Optional Overlay to catch clicks and open link */}
          {project.link && (
            <div className="absolute inset-0 z-10 flex items-center justify-center opacity-0 group-hover/preview:opacity-100 transition-all duration-500 bg-background/20 backdrop-blur-[2px] pointer-events-none">
              <Link href={project.link} target="_blank" rel="noopener noreferrer" className="px-6 py-2.5 bg-white text-black rounded-full text-sm font-semibold shadow-xl pointer-events-auto hover:scale-105 transition-transform duration-300">
                Visit Site
              </Link>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="flex-grow flex flex-col">
          <h3 className="font-bold text-xl mb-2.5 text-white/90 group-hover:text-white transition-colors">{project.title}</h3>
          <p className="text-muted-foreground text-sm leading-relaxed mb-6 max-h-[100px] overflow-y-auto pr-3 [&::-webkit-scrollbar]:w-1 [&::-webkit-scrollbar-track]:bg-transparent [&::-webkit-scrollbar-thumb]:bg-white/10 [&::-webkit-scrollbar-thumb]:rounded-full hover:[&::-webkit-scrollbar-thumb]:bg-white/20">
            {project.description}
          </p>
        </div>

        {/* Footer of Card (Tags & Arrow) */}
        <div className="flex items-end justify-between mt-auto pt-5 border-t border-white/5">
          <div className="flex flex-wrap gap-2 pr-4">
            {project.tags?.slice(0, 3).map((tag: string, tagIndex: number) => (
              <span
                key={tagIndex}
                className="px-2.5 py-1 bg-white/5 border border-white/10 text-[11px] font-medium text-white/70 rounded-full"
              >
                {tag}
              </span>
            ))}
            {(project.tags?.length || 0) > 3 && (
              <span className="px-2.5 py-1 bg-white/5 border border-white/10 text-[11px] font-medium text-white/50 rounded-full">
                +{(project.tags?.length || 0) - 3}
              </span>
            )}
          </div>

          {project.link && (
            <Link href={project.link} target="_blank" rel="noopener noreferrer" aria-label={`Visit ${project.title}`}>
              <button className="h-9 w-9 shrink-0 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 hover:text-white transition-all duration-300 text-white/70 group-hover:border-white/30 hover:-rotate-12">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M7 17l9.2-9.2M17 17V7H7"/>
                </svg>
              </button>
            </Link>
          )}
        </div>
      </div>
    </Card>
  );
}
