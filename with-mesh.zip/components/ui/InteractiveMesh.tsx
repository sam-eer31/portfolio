"use client";

import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { useRef, useMemo, useEffect } from "react";
import * as THREE from "three";
import { useInView } from "framer-motion";

import { vertexShader, fragmentShader } from "../../lib/shaders";

function SpacetimeGrid() {
  const meshRef = useRef<THREE.Mesh>(null);
  const materialRef = useRef<THREE.ShaderMaterial>(null);
  const ballRef = useRef<THREE.Mesh>(null);
  const { gl } = useThree();
  
  const mouse = useRef({ x: 0, y: 0 });
  const isInteracting = useRef(false);

  useEffect(() => {
    const updateMouse = (clientX: number, clientY: number) => {
      const rect = gl.domElement.getBoundingClientRect();
      const x = clientX - rect.left;
      const y = clientY - rect.top;
      
      mouse.current.x = (x / rect.width) * 2 - 1;
      mouse.current.y = -(y / rect.height) * 2 + 1;
    };

    // Desktop Events
    const handleMouseMove = (e: MouseEvent) => {
      isInteracting.current = true;
      updateMouse(e.clientX, e.clientY);
    };
    
    const handleMouseLeave = () => {
      isInteracting.current = false;
    };

    // Mobile Touch Events
    const handleTouchStart = (e: TouchEvent) => {
      isInteracting.current = true;
      if (e.touches.length > 0) {
        updateMouse(e.touches[0].clientX, e.touches[0].clientY);
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (isInteracting.current && e.touches.length > 0) {
        updateMouse(e.touches[0].clientX, e.touches[0].clientY);
      }
    };

    const handleTouchEnd = () => {
      isInteracting.current = false;
    };

    window.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseleave", handleMouseLeave);
    
    window.addEventListener("touchstart", handleTouchStart, { passive: true });
    window.addEventListener("touchmove", handleTouchMove, { passive: true });
    window.addEventListener("touchend", handleTouchEnd, { passive: true });
    window.addEventListener("touchcancel", handleTouchEnd, { passive: true });

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseleave", handleMouseLeave);
      window.removeEventListener("touchstart", handleTouchStart);
      window.removeEventListener("touchmove", handleTouchMove);
      window.removeEventListener("touchend", handleTouchEnd);
      window.removeEventListener("touchcancel", handleTouchEnd);
    };
  }, [gl]);

  const geometry = useMemo(() => new THREE.PlaneGeometry(40, 40, 150, 150), []);

  const uniforms = useMemo(() => ({
    uTime: { value: 0 },
    uMouse: { value: new THREE.Vector2(0, 0) },
    uColor: { value: new THREE.Color("#078C8C") }, // New Turquoise Accent
    uOpacity: { value: 0.85 },
    uStrength: { value: 0.0 } // Controls the intensity of the gravity well
  }), []);

  const targetLocalPos = useRef(new THREE.Vector3(0, 0, 0));
  
  // Create a mathematical plane that perfectly matches our mesh's position and rotation,
  // but shifted exactly to the depth of the ball (local Z = -2.9) so the mouse clicks perfectly on its center.
  const mathPlane = useMemo(() => {
    const groupRot = new THREE.Euler(-1.2, 0, 0);
    const normal = new THREE.Vector3(0, 0, 1).applyEuler(groupRot);
    
    const ballCenterWorld = new THREE.Vector3(0, 0, -2.9);
    ballCenterWorld.applyEuler(groupRot);
    ballCenterWorld.add(new THREE.Vector3(0, -2, -5)); 
    
    return new THREE.Plane().setFromNormalAndCoplanarPoint(normal, ballCenterWorld);
  }, []);

  useFrame((state, delta) => {
    if (!meshRef.current || !materialRef.current) return;
    
    // Smoothly interpolate the interaction strength (1.0 when touching/moving, 0.0 when released)
    const targetStrength = isInteracting.current ? 1.0 : 0.0;
    materialRef.current.uniforms.uStrength.value = THREE.MathUtils.lerp(
      materialRef.current.uniforms.uStrength.value,
      targetStrength,
      0.1
    );
    
    // Raycast from camera to the mathematical plane
    state.raycaster.setFromCamera(new THREE.Vector2(mouse.current.x, mouse.current.y), state.camera);
    const intersect = state.raycaster.ray.intersectPlane(mathPlane, new THREE.Vector3());
    
    if (intersect) {
      meshRef.current.worldToLocal(intersect);
      targetLocalPos.current.copy(intersect);
    }
    
    const mouseX = targetLocalPos.current.x;
    const mouseY = targetLocalPos.current.y;
    
    // Send data to GPU
    materialRef.current.uniforms.uTime.value += delta;
    materialRef.current.uniforms.uMouse.value.set(mouseX, mouseY);
    
    // Update the planet's position visually
    if (ballRef.current) {
      ballRef.current.position.set(mouseX, mouseY, -2.9);
      ballRef.current.rotation.x += delta * 0.4;
      ballRef.current.rotation.y += delta * 0.6;
      
      // Smoothly fade the planet out when the user stops touching/interacting
      const ballMat = ballRef.current.material as THREE.MeshBasicMaterial;
      ballMat.opacity = materialRef.current.uniforms.uStrength.value * 0.8;
    }
  });

  return (
    <group rotation={[-1.2, 0, 0]} position={[0, -2, -5]}>
      <mesh ref={meshRef} geometry={geometry}>
        <shaderMaterial 
          ref={materialRef}
          vertexShader={vertexShader}
          fragmentShader={fragmentShader}
          uniforms={uniforms}
          wireframe={true}
          transparent={true}
        />
      </mesh>
      
      <mesh ref={ballRef}>
        <sphereGeometry args={[0.1, 32, 32]} />
        <meshBasicMaterial 
          color="#078C8C" 
          wireframe={true} 
          transparent={true}
          opacity={0.0} 
        />
      </mesh>
    </group>
  );
}

export function InteractiveMesh() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { margin: "0px" });

  return (
    <div ref={containerRef} className="absolute inset-0 z-0 overflow-hidden pointer-events-none" style={{ backgroundColor: '#050B14' }}>
      <Canvas camera={{ position: [0, 0, 5], fov: 60 }} frameloop={isInView ? "always" : "demand"}>
        <fog attach="fog" args={['#050B14', 8, 30]} />
        {isInView && <SpacetimeGrid />}
      </Canvas>
    </div>
  );
}
